// Copyright 2025 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

//go:build cgo && darwin

package cgotest

import "testing"

func TestIssue76023(t *testing.T)          { issue76023(t) }
func TestGlobalDataDynimport(t *testing.T) { unsignedRelocDynimport(t) }
